package com.example.jamel123;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jamel123ApplicationTests {

	@Test
	void contextLoads() {
	}

}
