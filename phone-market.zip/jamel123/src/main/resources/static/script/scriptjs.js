 document.addEventListener("DOMContentLoaded", TP);


  async function getphones() {
    response = await fetch("/api/phone");
    const phones = await response.json();
    return phones;
    }

    async function retrievephones(){
    const phones = await getphones();
    // Get the <ul> element by its ID
    const phoneList = document.getElementById("list");
    phoneList.innerHTML="";
    // Loop through the array and create <li> elements for each customer name
    phones.forEach(phone =>{
        let li = document.createElement("li");
        li.innerHTML=JSON.stringify(phone);
        //li.textContent = "{ id : " + phone.id + ", firstName : " + phone.firstName + ", lastName : " + phone.lastName + ", category : " + customer.category + "}"
        phoneList.appendChild(li);
    });
    }

 async function getphones() {
     let response = await fetch("/api/phone");  // Declare response properly
     const phones = await response.json();
     return phones;
 }

 async function retrievephones(){
     const phones = await getphones();

     // Get the <ul> element by its ID
     const phoneList = document.getElementById("list");
     phoneList.innerHTML = "";

     // Loop through the array and create <li> elements for each phone
     phones.forEach(phone => {
         let li = document.createElement("li");
         li.innerHTML =JSON.stringify(phone);
         // li.innerHTML = `ID: ${phone.id}, Name: ${phone.name}, Price: ${phone.price}`;
         phoneList.appendChild(li);
     });
 }

 async function addphone(){
     const name = document.getElementById("name").value;
     const price = document.getElementById("price").value;

     const response = await fetch("/api/phone", {
         method: "POST",
         headers: {
             "Content-Type": "application/json"
         },
         body: JSON.stringify({ name, price })

     });
     }
    async function deletebyname() {
    const name=document.getElementById("delname").value;

///  response = await fetch("/api/phone/"+name,{
    response = await fetch(`/api/phone/${name}`,{

    method: 'DELETE' } );
    }
   async function deletebyid(id) {
    response = await fetch("/api/phone/del/"+id,{
    method: 'DELETE' } );
    }


async function TP (){
const tabel=document.getElementById("tbadd");
tabel.innerHTML="<tr><th>ID</th><th>NAME</th><th>PRICE</th><th>BUY?</th></tr>";
const phones = await getphones();
 phones.forEach(phone => {
         let row = document.createElement("tr");
         row.innerHTML+= `<td> ${phone.id} </td>`;
         row.innerHTML+= `<td> ${phone.name} </td>`;
         row.innerHTML+= `<td> ${phone.price} </td>`;
         row.innerHTML+= `<td><button onclick="deletebyid(${phone.id})">Buy</button></td>`;
         tabel.appendChild(row);
     });
}

async function search(){
const maxprice=document.getElementById("search").value;
  response = await fetch("/api/phone/search/"+maxprice);
  const phones = await response.json();
   const tabel=document.getElementById("tbadd");
   tabel.innerHTML="<tr><th>ID</th><th>NAME</th><th>PRICE</th><th>BUY?</th></tr>";
    phones.forEach(phone => {
            let row = document.createElement("tr");
            row.innerHTML+= `<td> ${phone.id} </td>`;
            row.innerHTML+= `<td> ${phone.name} </td>`;
            row.innerHTML+= `<td> ${phone.price} </td>`;
            row.innerHTML+= `<td><button onclick="deletebyid(${phone.id})">Buy</button></td>`;
            tabel.appendChild(row);
        });

}
