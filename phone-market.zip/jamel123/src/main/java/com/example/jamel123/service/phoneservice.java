package com.example.jamel123.service;
import com.example.jamel123.model.phone;
import com.example.jamel123.repository.phonerepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class phoneservice {
    @Autowired
    phonerepository  Phonerepository ;
    public List<phone> getAllphone(){
        return (List<phone>) Phonerepository.findAll();
    }
    public phone getphoneById(Long id){

        return Phonerepository.findById(id).orElse(null);
    }
    public void deletephoneById(Long id){
        Phonerepository.deleteById(id);
    }
    public void deletephoneByname(String name){
        List<phone>p=getAllphone();
        for (phone pp : p) {
            if(pp.getName().contains(name)){
                Phonerepository.deleteById(pp.getId());
            }
        }
        }
    public phone createphone(phone expression)
    {
        return Phonerepository.save(expression);
    }

    public List <phone> search( double price) {
        List<phone> l = getAllphone();
        List <phone> r = new ArrayList<phone>();
        for(phone x : l){
            if(x.getPrice()<=price)
                r.add(x);
        }
        return r;
    }
}
