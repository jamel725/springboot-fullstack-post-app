package com.example.jamel123.repository;

import com.example.jamel123.model.phone;
import org.springframework.data.jpa.repository.JpaRepository;

public interface phonerepository extends JpaRepository<phone,Long> {
}
