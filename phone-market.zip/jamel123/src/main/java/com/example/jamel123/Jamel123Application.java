package com.example.jamel123;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jamel123Application {

	public static void main(String[] args) {
		SpringApplication.run(Jamel123Application.class, args);
	}

}
