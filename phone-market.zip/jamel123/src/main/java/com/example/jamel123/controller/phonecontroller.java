package com.example.jamel123.controller;

import com.example.jamel123.model.phone;
import com.example.jamel123.service.phoneservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/phone")
public class phonecontroller {
    @Autowired
    public phoneservice phoneservice;

    @GetMapping("/{id}")
    public phone getphoneById(@PathVariable Long id) {
        return phoneservice.getphoneById(id);
    }

    @GetMapping
    public List<phone> getAllphone() {
        return phoneservice.getAllphone();
    }

    @PostMapping
    public phone addphone(@RequestBody phone phone) {
        return phoneservice.createphone(phone);
    }

    @GetMapping("/add")
    public phone addphone(@RequestParam String name, @RequestParam int price) {
        phone phone = new phone(name, price);
        return phoneservice.createphone(phone);
    }
    @DeleteMapping("/{name}")
    public void deletephoneByname(@PathVariable String name){
        phoneservice.deletephoneByname(name);
    }
    @DeleteMapping("/del/{id}")
    public void deletephoneByname(@PathVariable long id){
        phoneservice.deletephoneById(id);
    }
    @GetMapping("/search/{maxprice}")
    public  List<phone>search(@PathVariable double maxprice){
        return phoneservice.search(maxprice);
    }
}