package com.example.test.repository;

import com.example.test.model.post;
import org.springframework.data.jpa.repository.JpaRepository;

public interface postrepository extends JpaRepository<post,Long> {
}
