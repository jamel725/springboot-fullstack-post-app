package com.example.test.service;

import com.example.test.model.post;
import com.example.test.repository.postrepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class postservice {
    @Autowired
    postrepository postrepository;

    public List<post> getAllpost(){
        return (List<post>) postrepository.findAll();
    }
    public post getpostById(Long id){

        return postrepository.findById(id).orElse(null);
    }
    public void deletepostById(Long id){
        postrepository.deleteById(id);

    }

    public post createpost(post post)
    {
        return postrepository.save(post);
    }
    public void add (Long id){
        post p = getpostById(id);
        p.setLikes(p.getLikes()+1);
        postrepository.save(p);
    }

    public post edit(post post ){
        post p = getpostById(post.getId());
        p.setContent(post.getContent());
        p.setTitle(post.getTitle());
       return postrepository.save(p);

    }

}
