package com.example.test.controller;

import com.example.test.model.post;
import com.example.test.service.postservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/post")
public class postconroller {
    @Autowired
    public postservice postservice;



    @GetMapping
    public List<post> getAllpost() {
        return postservice.getAllpost();
    }
    @PostMapping
    public post editepost(@RequestBody post post){
       return postservice.edit(post);

    }

    @GetMapping("/add/{id}")
    public void add(@PathVariable Long id){
        postservice.add(id);

    }

}
