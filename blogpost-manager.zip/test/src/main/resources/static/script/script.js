document.addEventListener("DOMContentLoaded", fetchPosts);
async function fetchPosts() {
    response = await fetch("/api/post");
    const posts = await response.json();
    const tableBody = document.getElementById("postTableBody");
    tableBody.innerHTML="";
    posts.forEach(post => {
        const row = document.createElement("tr");
        row.innerHTML += `<td>${post.id}</td>`;
        row.innerHTML += `<td>${post.title}</td>`;
        row.innerHTML += `<td>${post.content}</td>`;
        row.innerHTML += `<td>${post.likes}</td>`;
        row.innerHTML += `<td><button onclick="incrementPostRead(${post.id})">Like</button></td>`;
        tableBody.appendChild(row);
    });
}

async function incrementPostRead(id) {
await fetch("/api/post/add/"+id);
fetchPosts();
}

async function editPost() {
     const id = document.getElementById("id").value;
     const title = document.getElementById("t").value;
     const content = document.getElementById("c").value;
     const response = await fetch("/api/post", {
             method: "POST",
             headers: {
                 "Content-Type": "application/json"
             },
             body: JSON.stringify({ id,title,content })

         });
         fetchPosts();
         }


